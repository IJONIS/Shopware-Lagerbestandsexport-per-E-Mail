# 1.0.0
- Erste Version des Lagerbestandsexport Plugins
- Automatischer Export von Lagerbeständen per E-Mail
- Konfigurierbare Export-Intervalle (täglich, wöchentlich, monatlich)
- Test-Funktion für E-Mail-Versand
- Export enthält Artikelnummer, EAN, Name und Lagerbestand
- Mehrsprachige Unterstützung (Deutsch/Englisch)
- Kommandozeilen-Interface für manuelle Exports
